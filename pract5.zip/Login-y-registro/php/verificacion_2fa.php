<?php
session_start();
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigo_ingresado = $_POST['codigo_verificacion'];
    $correo = $_SESSION['usuario'];

    $query = "SELECT codigo_verificacion FROM usuarios WHERE correo='$correo'";
    $resultado = mysqli_query($conexion, $query);
    $usuario = mysqli_fetch_assoc($resultado);

    if ($usuario['codigo_verificacion'] == $codigo_ingresado) {
        $_SESSION['verificado_2fa'] = true;
        echo '
        <script>
            alert("Verificación exitosa");
            window.location = "../bienvenido.php";
        </script>
        ';
    } else {
        echo '
        <script>
            alert("Código de verificación incorrecto");
            window.location = "verificacion_2fa.php";
        </script>
        ';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación 2FA</title>
</head>
<body>
    <form method="POST" action="verificacion_2fa.php">
        <h2>Verificación de dos factores</h2>
        <input type="text" name="codigo_verificacion" placeholder="Código de verificación" required>
        <button type="submit">Verificar</button>
    </form>
</body>
</html>