<?php 
session_start();
include 'conexion.php';
require '../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Google\Auth\OAuth2;

$correo = $_POST['correo'];
$contraseña = $_POST['contraseña'];

// Verificar las credenciales del usuario
$validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo' AND contraseña='$contraseña'");

if(mysqli_num_rows($validar_login) > 0){
    $usuario = mysqli_fetch_assoc($validar_login);
    
    // Generar un código de verificación de dos factores
    $codigo_verificacion = rand(100000, 999999);
    
    $mail = new PHPMailer(true);
try {
    // Configuración del servidor
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Cambia esto por el host de tu servidor SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'j06frank@gmail.com'; // Cambia esto por tu correo
    $mail->Password = 'Javier_07'; // Cambia esto por tu contraseña
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Destinatarios
    $mail->setFrom('tu_correo@example.com', 'Nombre');
    $mail->addAddress($correo);

    // Contenido del correo
    $mail->isHTML(true);
    $mail->Subject = 'Código de verificación';
    $mail->Body    = 'Tu código de verificación es: ' . $codigo_verificacion;
    $mail->send();
} catch (Exception $e) {
    echo "El mensaje no pudo ser enviado. Mailer Error: {$mail->ErrorInfo}";
}

    
    // Guardar el código en la sesión para su verificación posterior
    $_SESSION['codigo_verificacion'] = $codigo_verificacion;
    $_SESSION['usuario'] = $correo;

    // Redirigir a la página de verificación de 2FA
    header("location: verificacion_2fa.php");
    exit();
}else{
    echo '
    <script>
        alert("Usuario no encontrado, por favor verifique los datos introducidos");
        window.location = "../index.php";
    </script>
    ';
    exit();
}

mysqli_close($conexion);
?>