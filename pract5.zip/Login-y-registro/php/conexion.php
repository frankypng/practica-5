<?php
$conexion = mysqli_connect("localhost", "Ticst", "YNng!SP>7D*e9jcm", "login_register_db");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}
?>