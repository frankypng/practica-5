<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Cargar la librería de PHPMailer
require 'conexion.php';
session_start();

$nombre_completo = $_POST['nombre_completo'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$contraseña = $_POST['contraseña'];
$contraseña = password_hash($contraseña, PASSWORD_DEFAULT); // Encriptar la contraseña
// Verificar si el correo ya está registrado
$verificar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo'");  
if(mysqli_num_rows($verificar_correo) > 0){
    echo '
    <script>
        alert("Este correo ya está registrado, intenta con otro diferente");
        window.location = "../index.php";
    </script>
    ';
    exit();
}

// Verificar si el usuario ya está registrado
$verificar_usuario = mysqli_query($conexion, "SELECT * FROM usuarios WHERE usuario='$usuario'");
if(mysqli_num_rows($verificar_usuario) > 0){
    echo '
    <script>
        alert("Este usuario ya está registrado, intenta con otro diferente");
        window.location = "../index.php";
    </script>
    ';
    exit();
}

// Generar un código de verificación de dos factores
$codigo_verificacion = rand(100000, 999999);

// Almacenar el usuario en la base de datos
$query = "INSERT INTO usuarios(nombre_completo, correo, usuario, contraseña, codigo_verificacion) VALUES('$nombre_completo', '$correo', '$usuario', '$contraseña', '$codigo_verificacion')";
$ejecutar = mysqli_query($conexion, $query);

if($ejecutar){
    // Enviar el correo de verificación
    $mail = new PHPMailer(true);
    try {
        // Configuración del servidor
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Cambia esto por el host de tu servidor SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'tu_correo@gmail.com'; // Cambia esto por tu correo
        $mail->Password = 'tu_contraseña'; // Cambia esto por tu contraseña
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Destinatarios
        $mail->setFrom('tu_correo@gmail.com', 'Nombre');
        $mail->addAddress($correo);

        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = 'Código de verificación';
        $mail->Body    = 'Tu código de verificación es: ' . $codigo_verificacion;
        $mail->send();
    } catch (Exception $e) {
        echo "El mensaje no pudo ser enviado. Mailer Error: {$mail->ErrorInfo}";
    }

    // Redirigir al usuario a la página de inicio de sesión
    echo '
    <script>
        alert("Usuario almacenado correctamente. Por favor inicia sesión.");
        window.location = "../index.php";
    </script>
    ';
}else{
    echo '
    <script>
        alert("Inténtalo de nuevo, usuario no almacenado");
        window.location = "../index.php";
    </script>
    ';
}

mysqli_close($conexion);
?>